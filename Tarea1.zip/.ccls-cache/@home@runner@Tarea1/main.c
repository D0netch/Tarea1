#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "list.h"

int main( int argc, char *argv[] ){
  List* libros= createList();
  int menu;
  char *titulo = NULL;
  char *autor = NULL;
  char *genero = NULL;
  char *ubicacion = NULL;
  int isbn;
  
  printf("\n");
  //Ciclo iterativo para acceder a las funciones del menu.
  do{
    imprimir_menu();
    printf("\n");
    scanf("%i",&menu);
    getchar();
    printf("\n");
    //En caso de no ser un numero valido para el menu se saltará las lineas de codigo del menu
    if(menu>11 || menu<0) printf("Escriba un número valido");
    else{
      switch(menu){
        case 1: {
          printf("Ingrese el título: ");
          leerDato(&titulo,50);
          
          printf("Ingrese el autor: ");
          leerDato(&autor,50);

          printf("Ingrese el género: ");
          leerDato(&genero,50);

          printf("Ingrese la ubicación: ");
          leerDato(&ubicacion,50);
          
          printf("Ingrese el ISBN: ");
          scanf("%d", &isbn);
          getchar();
          
          registrarLibro(libros,titulo,autor,genero,ubicacion,isbn);
          free(titulo);
          free(autor);
          free(genero);
          free(ubicacion);
          break;
        }    
        case 2:{
          mostrarDatosLibro(libros);
          break;
        }
        case 3:
          mostrarTodosLosLibros(libros);
          break;
          case 4: {
          reservarLibro(libros);
          break;
            }
        case 5:
          cancelarReserva(libros);
          break;
        case 6:
          retirarLibro(libros);
          break;
        case 7:
          devolverLibro(libros);
          break;
        case 8:
          mostrarLibrosPrestados(libros);
          break;
        case 9:
          importarLibrosDesdeCSV(libros);
          break;
        case 10:
          exportarLibrosACSV(libros);
          break;

      }  
    }
    printf("\n");
  } while (menu != 11);
  
  printf("FIN DEL PROGRAMA");
  cleanList(libros);
  free(libros); // Liberar la estructura de la lista de libros en sí
  return 0;
}