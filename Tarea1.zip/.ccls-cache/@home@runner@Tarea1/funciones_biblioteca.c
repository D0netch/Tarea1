#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <assert.h>
#include <ctype.h>
#include "list.h"

typedef struct{
  char titulo[50];
  char autor[50];
  char genero[50];
  int isbn;
  char ubicacion[2];
  char estado[50];
  List *reservas;
}Libro;

