#ifndef list_h
#define list_h

typedef struct List List;
typedef struct Libro Libro;

List * createList(void);

void * firstList(List * list);

void * nextList(List * list);

void * lastList(List * list);

void * prevList(List * list);

void pushFront(List * list, void * data);

void pushBack(List * list, void * data);

void pushCurrent(List * list, void * data);

void * popFront(List * list);

void * popBack(List * list);

void * popCurrent(List * list);

void cleanList(List * list);

void imprimir_menu();

void leerDato(char **dato,int max);

void registrarLibro(List *Libros, const char titulo[], const char autor[], const char genero[], const char ubicacion[], int isbn);

bool isEmpty(List *list);

void mostrarDatosLibro(List *Libros);

void mostrarTodosLosLibros(List *Libros);

void reservarLibro(List *Libros);

void cancelarReserva(List *Libros);

void retirarLibro(List *Libros);

void devolverLibro(List *Libros);

void mostrarLibrosPrestados(List *Libros);

const char *get_csv_field (char * tmp, int k);

int countFields(const char *linea);

void importarLibrosDesdeCSV(List *Libros);

void exportarLibrosACSV(List *Libros);

#endif /* list_h */


