#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>
#include <string.h>
#include "list.h"

typedef struct Node Node;

struct Node {
    void * data;
    Node * next;
    Node * prev;
};

struct List {
    Node * head;
    Node * tail;
    Node * current;
};

struct Libro{
  char titulo[51];
  char autor[51];
  char genero[51];
  int isbn;
  char ubicacion[3];
  char estado[51];
  List *reservas;
};

typedef List List;

Node * createNode(void * data) {
    Node * new = (Node *)malloc(sizeof(Node));
    assert(new != NULL);
    new->data = data;
    new->prev = NULL;
    new->next = NULL;
    return new;
}

List * createList() {
     List * new = (List *)malloc(sizeof(List));
     assert(new != NULL);
     new->head = new->tail = new->current = NULL;
     return new;
}

void * firstList(List * list) {
    if (list == NULL || list->head == NULL) return NULL;
    list->current = list->head;
    return (void *)list->current->data;
}

void * nextList(List * list) {
    if (list == NULL || list->head == NULL || list->current == NULL || list->current->next == NULL) return NULL;
    list->current = list->current->next;
    return (void *)list->current->data;
}

void * lastList(List * list) {
    if (list == NULL || list->head == NULL) return NULL;
    list->current = list->tail;
    return (void *)list->current->data;
}

void * prevList(List * list) {
    if (list == NULL || list->head == NULL || list->current == NULL || list->current->prev == NULL) return NULL;
    list->current = list->current->prev;
    return (void *)list->current->data;
}

void pushFront(List * list, void * data) {
    assert(list != NULL);
    
    Node * new = createNode(data);
    
    if (list->head == NULL) {
        list->tail = new;
    } else {
        new->next = list->head;
        list->head->prev = new;
    }
    
    list->head = new;
}

void pushBack(List * list, void * data) {
    list->current = list->tail;
    if(list->current==NULL) pushFront(list,data);
    else pushCurrent(list,data);
}

void pushCurrent(List * list, void * data) {
    assert(list != NULL && list->current !=NULL);
    Node * new = createNode(data);

    if(list->current->next)
        new->next = list->current->next;
    new->prev = list->current;

    if(list->current->next)
        list->current->next->prev = new;
    list->current->next = new;

    if(list->current==list->tail)
        list->tail=new;

}

void * popFront(List * list) {
    list->current = list->head;
    return popCurrent(list);
}

void * popBack(List * list) {
    list->current = list->tail;
    return popCurrent(list);
}

void * popCurrent(List * list) {
    assert(list != NULL || list->head != NULL);
    
    if (list->current == NULL) return NULL;
    
    Node * aux = list->current;
    
    if (aux->next != NULL) 
        aux->next->prev = aux->prev;
    
    
    if (aux->prev != NULL) 
        aux->prev->next = aux->next;
    
    
    void * data = (void *)aux->data;
    
    if(list->current == list->tail)
        list->tail = list->current->prev;

    if(list->current == list->head)
        list->head = list->current->next;
        
    list->current = aux->prev;



    
    free(aux);
    
    return data;
}

void cleanList(List * list) {
    assert(list != NULL);
    
    while (list->head != NULL) {
        popFront(list);
    }
}

void limpiarBuffer(){
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

void imprimir_menu(){
  printf("Por favor ingrese el número de la función deseada\n");
  printf("1.Registrar Libro\n2.Mostrar datos de libro\n3.Mostrar todos los libros\n4.Reservar libro\n5.Cancelar reserva de libro\n6.Retirar libro\n7.Devolver libro\n8.Mostrar libros prestados\n9.Importar libros desde un archivo CSV\n10.Exportar libros desde un archivo CSV\n11.Salir\n");
}

void registrarLibro(List *Libros, const char titulo[], const char autor[], const char genero[], const char ubicacion[], int isbn) {

    // Crea un nuevo libro
    Libro *nuevoLibro = (Libro *)malloc(sizeof(Libro)); 

    if (nuevoLibro == NULL) {
        printf("Error: No se pudo asignar memoria para el nuevo libro.\n");
        return;
    }

    // Copia los datos proporcionados a la estructura del libro
    strcpy(nuevoLibro->titulo, titulo);
    strcpy(nuevoLibro->autor, autor);
    strcpy(nuevoLibro->genero, genero);
    strcpy(nuevoLibro->ubicacion, ubicacion);
    nuevoLibro->isbn = isbn;

    // Inicializa el estado y la lista de reservas
    strcpy(nuevoLibro->estado, "Disponible");
    nuevoLibro->reservas = createList();
    
    if (nuevoLibro->reservas == NULL) {
        printf("Error: No se pudo crear la lista de reservas para el nuevo libro. Por favor, inténtelo de nuevo.\n");
        free(nuevoLibro); // Liberar memoria si la creación de la lista falla
        return;
    }

    // Agrega el libro a la lista
    pushBack(Libros, nuevoLibro);
}

bool isEmpty(List *list) {
  return list->head == NULL;
}

void mostrarDatosLibro(List *Libros) {
  char titulo[50], autor[50];
          
  printf("Ingrese el título: ");
  fgets(titulo, sizeof(titulo), stdin);
  titulo[strlen(titulo) - 1] = '\0';
          
  printf("Ingrese el autor: ");
  fgets(autor, sizeof(autor), stdin);
  autor[strlen(autor) - 1] = '\0';
  printf("\n");
  void *data = firstList(Libros);

  while (data != NULL) {
    Libro *libro = (Libro *)data;

    // Comparar título y autor
    if (strcmp(libro->titulo, titulo) == 0 && strcmp(libro->autor, autor) == 0) {
      printf("Datos del libro:\n");
      printf("Título: %s\n", libro->titulo);
      printf("Autor: %s\n", libro->autor);
      printf("Género: %s\n", libro->genero);
      printf("ISBN: %d\n", libro->isbn);
      printf("Ubicación: %s\n", libro->ubicacion);
      printf("Estado: %s\n", libro->estado);

      if (libro->reservas != NULL && libro->reservas->head != NULL) {
        printf("Reservas:\n");
        Node *reservaNode = libro->reservas->head;
        int reservaIndex = 1; // Para llevar un registro del número de reserva
        while (reservaNode != NULL) {
          // Suponiendo que los nombres de los estudiantes se almacenan como cadenas
          // reservaNode->data debe contener el nombre del estudiante
          printf("%d. %s\n", reservaIndex, (char *)reservaNode->data);
          reservaNode = reservaNode->next;
          reservaIndex++;
        }
      } else {
          printf("No hay reservas para este libro.\n");
        }

      return; // Salir del bucle si encontramos el libro
    }

    data = nextList(Libros); // Avanzar al siguiente libro
  }

  // Si llegamos aquí, el libro no fue encontrado
  printf("El libro con título '%s' y autor '%s' no fue encontrado.\n", titulo, autor);
}

void mostrarTodosLosLibros(List *Libros) {
  void *data = firstList(Libros);

  if (data == NULL) {
    printf("No hay libros registrados.\n");
    return;
  }

  printf("Lista de libros:\n");
  while (data != NULL) {
    Libro *libro = (Libro *)data;

    printf("Título: %s\n", libro->titulo);
    printf("Autor: %s\n", libro->autor);
    printf("\n"); // Separador entre libros

    data = nextList(Libros); // Avanzar al siguiente libro
  }
}

void reservarLibro(List *Libros) {
  char titulo[51], autor[51], nombre_estudiante[51];
  char buffer[100]; // Usar un búfer adicional para limpiar el búfer de entrada

  printf("Ingrese el título del libro: ");
  fgets(titulo, sizeof(titulo), stdin);
  titulo[strlen(titulo) - 1] = '\0';

  printf("Ingrese el autor del libro: ");
  fgets(autor, sizeof(autor), stdin);
  autor[strlen(autor) - 1] = '\0';

  printf("Ingrese el nombre del estudiante: ");
  fgets(nombre_estudiante, sizeof(nombre_estudiante), stdin);
  nombre_estudiante[strlen(nombre_estudiante) - 1] = '\0';

  limpiarBuffer(); 

  Node *currentNode = Libros->head;

  while (currentNode != NULL) {
    Libro *libro = (Libro *)currentNode->data;

    // Comparar título y autor
    if (strcmp(libro->titulo, titulo) == 0 && strcmp(libro->autor, autor) == 0) {
      // Cambiar el estado del libro a "Reservado"
      strcpy(libro->estado, "Reservado");

      // Agregar la reserva a la cola de reservas del libro
      pushBack(libro->reservas, strdup(nombre_estudiante));

      printf("Reserva realizada correctamente.\n");
      return; // Salir del bucle si encontramos el libro
    }

    currentNode = currentNode->next; // Avanzar al siguiente libro
  }

  // Si llegamos aquí, el libro no fue encontrado
  printf("El libro con título '%s' y autor '%s' no fue encontrado.\n", titulo, autor);
}

void cancelarReserva(List *Libros) {
  char titulo[51], autor[51], nombre_estudiante[51];

  printf("Ingrese el título del libro: ");
  fgets(titulo, sizeof(titulo), stdin);
  titulo[strlen(titulo) - 1] = '\0';

  printf("Ingrese el autor del libro: ");
  fgets(autor, sizeof(autor), stdin);
  autor[strlen(autor) - 1] = '\0';

  printf("Ingrese el nombre del estudiante cuya reserva desea cancelar: ");
  fgets(nombre_estudiante, sizeof(nombre_estudiante), stdin);
  nombre_estudiante[strlen(nombre_estudiante) - 1] = '\0';

  Node *currentNode = Libros->head;

  while (currentNode != NULL) {
    Libro *libro = (Libro *)currentNode->data;

    // Comparar título y autor
    if (strcmp(libro->titulo, titulo) == 0 && strcmp(libro->autor, autor) == 0) {
      // Verificar si el libro está reservado
      if (strcmp(libro->estado, "Reservado") == 0) {
        // Verificar si el estudiante tiene una reserva
        if (!isEmpty(libro->reservas)) {
          // Buscar y eliminar la reserva del estudiante
          Node *reservaNode = libro->reservas->head;
          Node *prevNode = NULL;
          while (reservaNode != NULL) {
            char *reserva = (char *)reservaNode->data;
            if (strcmp(reserva, nombre_estudiante) == 0) {
              // Eliminar la reserva
              free(reservaNode->data);
              if (prevNode == NULL) {
                popFront(libro->reservas);
              } else {
                prevNode->next = reservaNode->next;
                free(reservaNode);
              }
              printf("Reserva de '%s' para el libro '%s' cancelada correctamente.\n", nombre_estudiante, libro->titulo);
              
              // Verificar si ya no hay reservas y actualizar el estado del libro
              if (isEmpty(libro->reservas)) {
                strcpy(libro->estado, "Disponible");
                printf("El libro '%s' ahora está disponible.\n", libro->titulo);
              }
              return;
            }
            prevNode = reservaNode;
            reservaNode = reservaNode->next;
          }
          printf("No se encontró una reserva para '%s' en el libro '%s'.\n", nombre_estudiante, libro->titulo);
        } else {
          printf("No hay reservas para este libro.\n");
        }
      } else {
        printf("El libro con título '%s' y autor '%s' no está reservado.\n", titulo, autor);
      }
      return;
    }

    currentNode = currentNode->next; // Avanzar al siguiente libro
  }

  // Si llegamos aquí, el libro no fue encontrado
  printf("El libro con título '%s' y autor '%s' no fue encontrado.\n", titulo, autor);
}

void retirarLibro(List *Libros) {
  char titulo[51], autor[51], nombre_estudiante[51];

  printf("Ingrese el título del libro: ");
  fgets(titulo, sizeof(titulo), stdin);
  titulo[strlen(titulo) - 1] = '\0';

  printf("Ingrese el autor del libro: ");
  fgets(autor, sizeof(autor), stdin);
  autor[strlen(autor) - 1] = '\0';

  printf("Ingrese su nombre para retirar el libro: ");
  fgets(nombre_estudiante, sizeof(nombre_estudiante), stdin);
  nombre_estudiante[strlen(nombre_estudiante) - 1] = '\0';

  Node *currentNode = Libros->head;

  while (currentNode != NULL) {
    Libro *libro = (Libro *)currentNode->data;

    // Comparar título y autor
    if (strcmp(libro->titulo, titulo) == 0 && strcmp(libro->autor, autor) == 0) {
      if (strcmp(libro->estado, "Disponible") == 0) {
        strcpy(libro->estado, "Prestado");
        printf("El libro '%s' ha sido prestado a '%s'.\n", libro->titulo, nombre_estudiante);
        return;
      } else if (strcmp(libro->estado, "Prestado") == 0) {
        printf("El libro con título '%s' y autor '%s' ya está prestado.\n", titulo, autor);
        return;
      } else if (strcmp(libro->estado, "Reservado") == 0) {
        if (isEmpty(libro->reservas)) {
          // No hay reservas, marcar como prestado
          strcpy(libro->estado, "Prestado");
          printf("El libro '%s' ha sido prestado a '%s'.\n", libro->titulo, nombre_estudiante);
        } else {
          // Verificar si el estudiante actual está en la cola de reservas
          Node *reservaNode = libro->reservas->head;
          while (reservaNode != NULL) {
            char *estudiante = (char *)reservaNode->data;
            if (strcmp(estudiante, nombre_estudiante) == 0) {
              // Estudiante encontrado en la cola de reservas, marcar como prestado
              strcpy(libro->estado, "Prestado");
              popFront(libro->reservas); // Eliminar al estudiante de la cola de reservas
              printf("El libro '%s' ha sido prestado a '%s'.\n", libro->titulo, nombre_estudiante);
              return;
            }
            reservaNode = reservaNode->next;
          }
          // Estudiante no encontrado en la cola de reservas, mostrar aviso
          printf("El estudiante '%s' no tiene prioridad para retirar el libro '%s'.\n", nombre_estudiante, libro->titulo);
        }
      }
    }

    currentNode = currentNode->next; // Avanzar al siguiente libro
  }

  // Si llegamos aquí, el libro no fue encontrado
  printf("El libro con título '%s' y autor '%s' no fue encontrado.\n", titulo, autor);
}

void devolverLibro(List *Libros) {
  char titulo[51], autor[51];

  printf("Ingrese el título del libro a devolver: ");
  fgets(titulo, sizeof(titulo), stdin);
  titulo[strlen(titulo) - 1] = '\0';

  printf("Ingrese el autor del libro a devolver: ");
  fgets(autor, sizeof(autor), stdin);
  autor[strlen(autor) - 1] = '\0';

  Node *currentNode = Libros->head;

  while (currentNode != NULL) {
    Libro *libro = (Libro *)currentNode->data;

    // Comparar título y autor
    if (strcmp(libro->titulo, titulo) == 0 && strcmp(libro->autor, autor) == 0) {
      if (strcmp(libro->estado, "Prestado") == 0) {
        // El libro está prestado, lo marcamos como "Reservado" si hay cola de reservas
        if (libro->reservas != NULL && libro->reservas->head != NULL) {
          strcpy(libro->estado, "Reservado");
          printf("El libro '%s' ha sido devuelto y ahora está reservado.\n", libro->titulo);
        } else {
          // Si no hay cola de reservas, lo marcamos como "Disponible"
          strcpy(libro->estado, "Disponible");
          printf("El libro '%s' ha sido devuelto y ahora está disponible.\n", libro->titulo);
        }
      } else if (strcmp(libro->estado, "Reservado") == 0) {
        // El libro está reservado, no se puede devolver
        printf("El libro '%s' está reservado.\n", libro->titulo);
      } else {
        // El libro está disponible, no hacemos nada
        printf("El libro '%s' ya está en estado disponible.\n", libro->titulo);
      }
      return;
    }

    currentNode = currentNode->next; // Avanzar al siguiente libro
  }

  // Si llegamos aquí, el libro no fue encontrado
  printf("El libro con título '%s' y autor '%s' no fue encontrado.\n", titulo, autor);
}

void mostrarLibrosPrestados(List *Libros) {
  Node *currentNode = Libros->head;
  bool prestados = false;

  while (currentNode != NULL) {
    Libro *libro = (Libro *)currentNode->data;

    // Verificar si el libro está prestado
    if (strcmp(libro->estado, "Prestado") == 0) {
      // Verificar si hay reservas
      if (libro->reservas != NULL && libro->reservas->head != NULL) {
        // Obtener el nombre del estudiante al que se le prestó
        char *nombreEstudiante = (char *)libro->reservas->head->data;
        printf("Título: %s\n", libro->titulo);
        printf("Autor: %s\n", libro->autor);
        printf("Prestado a: %s\n\n", nombreEstudiante);
        prestados = true;
      }
    }

    currentNode = currentNode->next; // Avanzar al siguiente libro
  }

  if (!prestados) {
    printf("No hay libros prestados en este momento.\n");
  }
}

const char *get_csv_field (char * tmp, int k) {
    int open_mark = 0;
    char* ret=(char*) malloc (100*sizeof(char));
    int ini_i=0, i=0;
    int j=0;
    while(tmp[i+1]!='\0'){

        if(tmp[i]== '\"'){
            open_mark = 1-open_mark;
            if(open_mark) ini_i = i+1;
            i++;
            continue;
        }

        if(open_mark || tmp[i]!= ','){
            if(k==j) ret[i-ini_i] = tmp[i];
            i++;
            continue;
        }

        if(tmp[i]== ','){
            if(k==j) {
               ret[i-ini_i] = 0;
               return ret;
            }
            j++; ini_i = i+1;
        }

        i++;
    }

    if(k==j) {
       ret[i-ini_i] = 0;
       return ret;
    }


    return NULL;
}

int countFields(const char *linea) {
    int campos = 0;
    int longitud = strlen(linea);
    int dentro_del_campo = 0;

    for (int i = 0; i < longitud; i++) {
        if (linea[i] == ',') {
            // Si encontramos una coma y no estamos dentro de un campo entre comillas, incrementamos el contador de campos
            if (!dentro_del_campo) {
                campos++;
            }
        } else if (linea[i] == '"') {
            // Cambiamos el estado de "dentro_del_campo" cuando encontramos comillas
            dentro_del_campo = 1 - dentro_del_campo;
        }
    }

    // Agregamos 1 al contador final para incluir el último campo
    return campos + 1;
}

void importarLibrosDesdeCSV(List *Libros) {
    char nombre_archivo[100];

    printf("Ingrese el nombre del archivo CSV: ");
    fgets(nombre_archivo, sizeof(nombre_archivo), stdin);
    nombre_archivo[strlen(nombre_archivo) - 1] = '\0';

    FILE *archivo = fopen(nombre_archivo, "r");
    if (archivo == NULL) {
        printf("No se pudo abrir el archivo %s\n", nombre_archivo);
        return;
    }

    char linea[1024]; // Suponemos que cada línea del archivo CSV tiene un máximo de 1024 caracteres

    // Leer y omitir la primera línea (encabezados)
    if (fgets(linea, sizeof(linea), archivo) == NULL) {
        fclose(archivo);
        printf("El archivo CSV está vacío o no se pudo leer.\n");
        return;
    }

    while (fgets(linea, sizeof(linea), archivo)) {
        // Verifica si la línea tiene al menos 6 campos (titulo, autor, genero, isbn, ubicacion, estado)
        if (countFields(linea) >= 6) {
            const char *titulo = get_csv_field(linea, 0);
            const char *autor = get_csv_field(linea, 1);
            const char *genero = get_csv_field(linea, 2);
            int isbn = atoi(get_csv_field(linea, 3));
            const char *ubicacion = get_csv_field(linea, 4);
            const char *estado = get_csv_field(linea, 5);

            List *reservas = NULL;

            // Verifica si hay reservas (más de 6 campos)
            if (countFields(linea) > 6) {
                // Las reservas están a partir de la columna 6 (índice 5)
                reservas = createList();
                int reserva_index = 6;
                const char *reserva = NULL;

                // Procesar las reservas
                while ((reserva = get_csv_field(linea, reserva_index)) != NULL) {
                    pushBack(reservas, strdup(reserva));
                    reserva_index++;
                }
            }

            // Registrar el libro en la lista con sus datos
            registrarLibro(Libros, titulo, autor, genero, ubicacion, isbn);

            // Obtener el libro recién registrado
            Libro *nuevoLibro = lastList(Libros);

            // Establecer el estado y las reservas del libro
            strcpy(nuevoLibro->estado, estado);
            nuevoLibro->reservas = reservas;
        } 
    }

    fclose(archivo);
}

void exportarLibrosACSV(List *Libros) {
    char nombre_archivo[100];

    printf("Ingrese el nombre del archivo CSV para exportar los libros: ");
    fgets(nombre_archivo, sizeof(nombre_archivo), stdin);
    nombre_archivo[strlen(nombre_archivo) - 1] = '\0';

    FILE *archivo = fopen(nombre_archivo, "w");
    if (archivo == NULL) {
        printf("No se pudo abrir el archivo %s para escritura.\n", nombre_archivo);
        return;
    }

    // Escribir encabezados al archivo CSV
    fprintf(archivo, "Título,Autor,Género,ISBN,Ubicación,Estado,Reservas\n");

    // Recorrer la lista de libros y escribir cada libro en una línea del archivo CSV
    void *data = firstList(Libros);
    while (data != NULL) {
        Libro *libro = (Libro *)data;

        // Escribir los datos del libro en el archivo CSV
        fprintf(archivo, "%s,%s,%s,%d,%s,%s", libro->titulo, libro->autor, libro->genero, libro->isbn, libro->ubicacion, libro->estado);

        // Escribir las reservas (si las hay) en la misma línea
        if (libro->reservas != NULL && libro->reservas->head != NULL) {
            Node *reservaNode = libro->reservas->head;
            while (reservaNode != NULL) {
                fprintf(archivo, ",%s", (char *)reservaNode->data);
                reservaNode = reservaNode->next;
            }
        }

        fprintf(archivo, "\n"); // Nueva línea para el siguiente libro
        data = nextList(Libros); // Avanzar al siguiente libro
    }

    fclose(archivo);
    printf("Los libros se han exportado correctamente al archivo CSV: %s\n", nombre_archivo);
}